#include "AQUEUE.h"
#include <stdio.h>
#include <stdlib.h> 
void InitAQueue(AQueue *Q) {//初始化 
	Q->data=(int *)malloc(MAXQUEUE*sizeof(int));
	Q->front=Q->rear=0;//等于零是为了从第一位开始
	Q->length=0;
	printf("初始化成功\n\n");
} 
void DestoryAQueue(AQueue *Q) {
	free(Q->data);
	Q->data=NULL;
	printf("队列已销毁，请重新初始化"); 
}
Status IsFullAQueue( AQueue *Q) {
	if((Q->rear+1)%MAXQUEUE==Q->front)
	return TRUE;
	else
	return FALSE; 
}
Status IsEmptyAQueue( AQueue *Q) {
	if(Q->front==Q->rear)//相等说明没放元素 
	return TRUE;
	else return FALSE;
}
Status GetHeadAQueue(AQueue *Q, int *e) {
	if(IsEmptyAQueue(Q))
	return FALSE;
	else 
	{
		*e=Q->data[Q->front];
		return TRUE;
	}
}
int LengthAQueue(AQueue *Q) {
	return Q->length;
}	
Status EnAQueue(AQueue *Q, int *data) {//入队 
	if(IsFullAQueue(Q))
	return FALSE;
	else
	{
		Q->data[Q->rear]=*data;
		Q->rear++;//先赋值再移动rear指针 
		Q->length++;
		return TRUE;
	}
}
Status DeAQueue(AQueue *Q, int *data) {
	if(IsEmptyAQueue(Q))
	return FALSE;
	else
	{
		*data=Q->data[Q->front];
		Q->front++;
		Q->length--;	
		return TRUE;
	} 
}
void ClearAQueue(AQueue *Q) {
	printf("队列已空");
	Q->front=Q->rear;
	Q->length=0; 
}					//定义一个名称为foo的指向打印函数的指针 	 
Status TraverseAQueue(AQueue *Q, void (*foo)(int *q)) {
	int e,i;
	for(i=Q->front;i<Q->rear;i++) 
	{	
		e=Q->data[i]; 
		foo(&e); 
	}
}
void enAQueue(AQueue *Q){
	int e; 
	printf("请输入元素:");
	scanf("%d",&e);
	if(EnAQueue(Q,&e))
	printf("入队成功");
	else printf("入队失败"); 
}	
void deAQueue(AQueue *Q){
	int e; 
	if(DeAQueue(Q,&e))
	printf("元素%d已出队",e);
	else printf("出队失败"); 
}
void getHead(AQueue *Q){
	int e; 
	if(GetHeadAQueue(Q,&e))
	printf("队头元素为%d",e);
	else printf("队列为空");
}
void empty(AQueue *Q){
	if(IsEmptyAQueue(Q))
	printf("队列为空");
	else printf("队列不为空");
}
void full(AQueue *Q){
	if(IsFullAQueue(Q))
	printf("队列已满");
	else printf("队列未满");
}
void length(AQueue *Q){
	int e;
	e=LengthAQueue(Q);
	printf("队列长度为%d",e);
}
void menu()
{
   printf("			welcome!\n"); 
   printf("			-----------------------------------------\n");
   printf("			1.初始化(第一步)  		2.入队\n");	
   printf("			3.出队     			4.销毁\n");
   printf("			5.取队头    			6.判断空\n");
   printf("			7.判断满 			8.检测长度 \n");
   printf("			9.清空				10.遍历\n");
   printf("			11.退出\n");
   printf("			-----------------------------------------\n");
   printf("			请选择功能模块，输入数字1-11:");
}