#include <stdio.h>
#include "AQUEUE.h"
void APrint(int *q){
	printf("%d",*q);
}
int main (int argc, char** argv) {
		int i;
		AQueue Q;
		while(1)
		{	menu();
			int choice;
			scanf("%d",&choice);
			if(choice==11)break;
   			switch(choice)
   			{ 
   				case 1:InitAQueue(&Q);;break;
				case 2:enAQueue(&Q);break;
				case 3:deAQueue(&Q);break;
				case 4:DestoryAQueue(&Q);break;
				case 5:getHead(&Q);break;
				case 6:empty(&Q);break;
				case 7:full(&Q);break;
				case 8:length(&Q);break;
				case 9:ClearAQueue(&Q);break;
				case 10:TraverseAQueue(&Q,APrint);break;
				default:printf("输入数字不正确，请重新输入\n");
			   }
		}
}