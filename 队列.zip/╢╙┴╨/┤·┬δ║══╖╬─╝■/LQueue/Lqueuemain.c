#include <stdio.h>
#include "LQUEUE.h"
void LPrint(int *q){
	printf("%d",*q);
}
int main (int argc, char** argv) {
		int i;
		LQueue Q;
		while(1)
		{	menu();
			int choice;
			scanf("%d",&choice);
			if(choice==7)break;
   			switch(choice)
   			{ 
   				case 1:InitLQueue(&Q);;break;
				case 2:enLQueue(&Q);break;
				case 3:deLQueue(&Q);break;
				case 4:DestoryLQueue(&Q);break;
				case 5:getHead(&Q);break;
				case 6:empty(&Q);break;
				case 8:length(&Q);break;
				case 9:ClearLQueue(&Q);break;
				case 10:TraverseLQueue(&Q,LPrint);break;
				default:printf("输入数字不正确，请重新输入\n");
			   }
		}
}