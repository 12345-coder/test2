#include <stdio.h>
#include <stdlib.h>
#include "LQUEUE.h"
/**
 *  @name        : void InitLQueue(LQueue *Q)
 *    @description : 初始化队列
 *    @param         Q 队列指针Q
 *  @notice      : None
 */
void InitLQueue(LQueue *Q){
	Q->front=Q->rear=(Node*)malloc(sizeof(Node));
	Q->length=0;
	Q->rear->next=NULL;
	printf("初始化成功");
}

/**
 *  @name        : void DestoryLQueue(LQueue *Q)
 *    @description : 销毁队列
 *    @param         Q 队列指针Q
 *  @notice      : None
 */
void DestoryLQueue(LQueue *Q){
	free(Q->front);
	Q->front=Q->rear=NULL;//不能去掉，否则可以继续操作 
	printf("销毁成功,请重新初始化"); 
}

/**
 *  @name        : Status IsEmptyLQueue(const LQueue *Q)
 *    @description : 检查队列是否为空
 *    @param         Q 队列指针Q
 *    @return         : 空-TRUE; 未空-FALSE
 *  @notice      : None
 */
Status IsEmptyLQueue(LQueue *Q){
	if(Q->front==Q->rear)
	return TRUE;
	else 
	return FALSE;
}

/**
 *  @name        : Status GetHeadLQueue(LQueue *Q, void *e)
 *    @description : 查看队头元素
 *    @param         Q e 队列指针Q,返回数据指针e
 *    @return         : 成功-TRUE; 失败-FALSE
 *  @notice      : 队列是否空
 */
Status GetHeadLQueue(LQueue *Q, int *e){
	if(IsEmptyLQueue(Q))
	return FALSE;
	else
	{
	*e=Q->front->next->data;//头节点不存放数据
	return TRUE;			//或者最后结点不存放均可 
	} 
}

/**
 *  @name        : int LengthLQueue(LQueue *Q)
 *    @description : 确定队列长度
 *    @param         Q 队列指针Q
 *    @return         : 成功-TRUE; 失败-FALSE
 *  @notice      : None
 */
int LengthLQueue(LQueue *Q){
	return Q->length;
}

/**
 *  @name        : Status EnLQueue(LQueue *Q, void *data)
 *    @description : 入队操作
 *    @param         Q 队列指针Q,入队数据指针data
 *    @return         : 成功-TRUE; 失败-FALSE
 *  @notice      : 队列是否为空
 */
Status EnLQueue(LQueue *Q, int *data){
	Node *p;	
	p=(Node*)malloc(sizeof(Node));
	if(p==NULL)
	return FALSE;
	else
	{
		Q->rear->next=p;
		Q->rear=p;
		Q->rear->data=*data;
		Q->rear->next=NULL;
		Q->length++;
		return TRUE;	
	}
}

/**
 *  @name        : Status DeLQueue(LQueue *Q)
 *    @description : 出队操作
 *    @param         Q 队列指针Q
 *    @return         : 成功-TRUE; 失败-FALSE
 *  @notice      : None
 */
Status DeLQueue(LQueue *Q){
	Node *p=Q->front;
	if(IsEmptyLQueue(Q))
	return FALSE;
	else
	{
		Q->front=Q->front->next;
		free(p);
		Q->length--;
		return TRUE;
	}	
}

/**
 *  @name        : void ClearLQueue(AQueue *Q)
 *    @description : 清空队列
 *    @param         Q 队列指针Q
 *  @notice      : None
 */
void ClearLQueue(LQueue *Q){
		Node *p;
		printf("队列已空"); 
		while(Q->front->next)//类似链表的清空 
		{
			p=Q->front;
			Q->front=Q->front->next;
			free(p);	
		}
		Q->length=0;		 
}

/**
 *  @name        : Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q))
 *    @description : 遍历函数操作
 *    @param         Q 队列指针Q，操作函数指针foo
 *    @return         : None
 *  @notice      : None
 */
Status TraverseLQueue(LQueue *Q, void (*foo)(int *q)){
	int e;
	Node *p=Q->front;
	for(;p->next;p=p->next)
	{
		e=p->next->data;
		foo(&e);	
	}
}

/**
 *  @name        : void LPrint(void *q)
 *    @description : 操作函数
 *    @param         q 指针q
 
 *  @notice      : None
 */
void enLQueue(LQueue *Q){
	int e; 
	printf("请输入元素:");
	scanf("%d",&e);
	if(EnLQueue(Q,&e))
	printf("入队成功");
	else printf("入队失败"); 
}	
void deLQueue(LQueue *Q){
	int e; 
	if(DeLQueue(Q))
	printf("出队成功");
	else printf("出队失败"); 
}
void empty(LQueue *Q){
	if(IsEmptyLQueue(Q))
	printf("队列为空");
	else printf("队列不为空");
}
void length(LQueue *Q){
	int e;
	e=LengthLQueue(Q);
	printf("队列长度为%d",e);
}
void getHead(LQueue *Q){
	int e; 
	if(GetHeadLQueue(Q,&e))
	printf("队头元素为%d",e);
	else printf("队列为空");
}
void menu()
{
   printf("			welcome!\n"); 
   printf("			-----------------------------------------\n");
   printf("			1.初始化(第一步)  		2.入队\n");	
   printf("			3.出队     			4.销毁\n");
   printf("			5.取队头    			6.判断空\n");
   printf("			7.退出				8.检测长度 \n");
   printf("			9.清空				10.遍历\n");
   printf("			-----------------------------------------\n");
   printf("			请选择功能模块，输入数字1-10:");
}